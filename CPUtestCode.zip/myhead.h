//
// Created by wty on 2022/3/30.
//

#ifndef UNTITLED2_MYHEAD_H
#define UNTITLED2_MYHEAD_H
#define printf printf("Author: tianyiwang\n"); printf
#endif //UNTITLED2_MYHEAD_H

